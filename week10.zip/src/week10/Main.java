package week10;

import java.util.ArrayList;
import java.util.Scanner;


public class Main  {
    private double side1 = 1.0;
    private double side2 = 1.0;
    private double side3 = 1.0;
    private double color;
    private double filled;

    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);
        Triangle t1 = new Triangle();
        Triangle t2 = new Triangle();
        Triangle t3 = new Triangle();

        System.out.println("This program gets input for three triangles from the user.\n" +
                "It then creates three Triangle objects and displays the\n" +
                "description of each.");
        System.out.println("Enter the color of the triangle: ");
        Scanner scan = new Scanner(System.in);


        String color = input.next();
        String side1 = input.nextLine();
        String side2 = input.nextLine();
        String side3 = input.nextLine();


        System.out.println("Is the triangle filled? 'y' or 'n': ");
        Scanner input_2 = new Scanner(System.in);
        String filled = input.next();


        System.out.println("Enter the lengths of the three sides of the triangle: ");
        Scanner scanner = new Scanner(System.in);


    }
    {
      new Triangle(side1, side2, side3);
      for(int triangle = 0; triangle < 2; triangle += 2);
      System.out.println("Triangle");


        System.out.println("The Triangle Sides are \n side 1: " + side1 + "\n Side 2: " + side2 + "\n Side 3: " + side3);
        System.out.println("The Triangle's Area is " + (side1 + side2 + side3) / 2);

        System.out.println("The color of the triangle is: " + color);
        System.out.print("Is the triangle filled: " + filled);
        System.out.println("Goodbye");




    }
}


